//
//  SleepData.m
//  bluedemo
//
//  Created by user on 16/8/6.
//  Copyright © 2016年 user. All rights reserved.
//

#import "SleepData.h"

@implementation SleepData

// Insert code here to add functionality to your managed object subclass

@end
