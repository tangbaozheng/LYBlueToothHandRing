//
//  btconnect.m
//  bluedemo
//
//  Created by user on 16/8/3.
//  Copyright © 2016年 user. All rights reserved.
//

#import "btconnect.h"
#import "ViewController.h"
#import "SleepData.h"
#import "SleepData+CoreDataProperties.h"
#import "MoveData.h"
#import "MoveData+CoreDataProperties.h"
#import <CoreData/CoreData.h>


@implementation btconnect






//创建中心设备
- (CBCentralManager *) centralManager{
    if (!self.centralManager) {
        self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return self.centralManager;
}


//保存外设
- (NSMutableArray *) peripherals{
    if (!_peripherals) {
        self.peripherals = [NSMutableArray array];
    }
    return self.peripherals;
}

//监测蓝牙状态改变
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    if (central.state == CBCentralManagerStatePoweredOn) {
        //扫描外围设备
        [self.centralManager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:kServiceUUID]] options:nil];
    }else{
        NSLog(@"未打开蓝牙设备或此设备不支持蓝牙4.0");
    }
    
}

//找到外围设备
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI{
    NSLog(@"找到手环外设");
    [self.centralManager stopScan];//找到后停止扫描
    if (peripheral) {
        if (![self.peripherals containsObject:peripheral]) {
            [self.peripherals addObject:peripheral];
            
        }
        self.peripheral = peripheral;
    }
    
    
    //链接外围设备
    [self.centralManager connectPeripheral:peripheral options:nil];
}

//链接到所选外围设备
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    peripheral.delegate = self;//设置当前设备为代理设备

    //发现此设备的服务
    [self.peripheral discoverServices:@[[CBUUID UUIDWithString:kServiceUUID]]];
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"连接失败，请重新连接");
    //链接外围设备
    [self.centralManager connectPeripheral:peripheral options:nil];//重新连接手环
}

//找到服务后
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    if (error) {
        NSLog(@"出现错误:%@",error.localizedDescription);
        //发现此设备的服务
        [self.peripheral discoverServices:@[[CBUUID UUIDWithString:kServiceUUID]]];//重新查找手环服务
    }
    //    CBUUID *serverUUID = [CBUUID UUIDWithString:kServiceUUID];
    
    //手环特征数组
    NSArray<CBUUID *> *charateristUUID = @[[CBUUID UUIDWithString:kCharacteristicUUID1],[CBUUID UUIDWithString:kCharacteristicUUID2]];
    
    for (CBService *service in peripheral.services) {
        if ([service.UUID.UUIDString isEqualToString:kServiceUUID]) {
            //发现手环特征
            [self.peripheral discoverCharacteristics:charateristUUID forService:service];
        }
        
    }
}

//找到该服务下的2个特征
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    if (error) {
        //手环特征数组
        NSArray<CBUUID *> *charateristUUID = @[[CBUUID UUIDWithString:kCharacteristicUUID1],[CBUUID UUIDWithString:kCharacteristicUUID2]];
        //发现手环特征
        [self.peripheral discoverCharacteristics:charateristUUID forService:service];
    } else {
        for (CBCharacteristic *character in service.characteristics) {
            if ([character.UUID.UUIDString isEqualToString:kCharacteristicUUID1]) {
                
                //把数据放在字节数组中写到外围设备
                if (peripheral && character) {
                    self.charac_W = character;
                }
                
            } else if([character.UUID.UUIDString isEqualToString:kCharacteristicUUID2]){
                
                //订阅手环通知
                if (peripheral && character) {
                    self.charac_N = character;
                    [self.peripheral setNotifyValue:YES forCharacteristic:character];
                    [self.peripheral readValueForCharacteristic:character];
                }
                
            }
            //      [self.peripheral discoverDescriptorsForCharacteristic:character];
            //        [self.peripheral readValueForCharacteristic:character];
        }
    }
}

//- (void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
//    for (CBDescriptor *dp in characteristic.descriptors) {
//       [self.peripheral readValueForDescriptor:dp];
// //   }
//}


//成功写入数据到手环
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (error) {
        NSLog(@"发生错误，写入数据失败，请重新写入");
    }else{
        NSLog(@"写入数据成功！");
    }
}


//订阅手环通知，收到更新后获取手环信息
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (error) {
        NSLog(@"获取信息失败，请重新获取！");
        [self.peripheral readValueForCharacteristic:self.charac_N];//读取失败 重新等待读取
    }else{
        //获取手环信息数据
        if([characteristic.UUID.UUIDString isEqualToString:kCharacteristicUUID2]){
           // characteristic.value.bytes;
            
            Byte *info = (Byte *)characteristic.value.bytes;
            SleepData *sd = [[SleepData alloc] init];
            MoveData *md = [[MoveData alloc] init];
            int step;//步数；
            int miles;//运动里程
            int currentCalorie;//当前消耗卡路里
            int staticCalorie;//静卡路里
            int battery;//电池电量
            int rate ;//心率
            int year ;//年
            int month ;//月
            int day ;//日
            int sleepMin;//入睡时间
            int sleepSecondMin;//第二阶段时间
            int deepSleepMin;;//深度睡眠时间
            int shallowSleepMin;//浅睡眠时间
            int breakSleep;//中途醒时间
            int breakCount;//中途醒次数
            int startSleepH;//开始睡眠 时
            int startSleepM;//开始睡眠 分
            int today_step;//今日步数
            int today_miles;//今日里程
            int today_calorie;//今日消耗卡路里
            int today_staticCalorie;//今日静止卡路里
            int today_year;//今日 年
            int today_mon;//今日 月
            int today_day;//今日 日
            int today_move;//今日运动时间
            int today_rateMax;//今日心率最大值
            int today_rateMin;//今日新绿最小值
            
            
            switch (info[0]) {
                    //运动实时数据 16进制存储
                case 51:
                    step = (info[2] << 8 | info[1]);
                    miles = (info[4] << 8 | info[3]);
                    currentCalorie = (info[6] << 8 | info[5]);
                    staticCalorie = info[8] << 8 | info[7];
                    battery = info[9];
                    rate = info[11];
                    if (rate == 255 || rate == 0) {
                        NSLog(@"Invalid rate");
                    }
                    break;
                    //睡眠累计数据 每日一笔 16进制
                case 26:
                    year = info[2] << 8 | info[1];
                    month = info[3];
                    day = info[4];
                    sleepMin = info[6] << 8 | info[5];
                    sleepSecondMin = info[8] << 8 | info[7];
                    deepSleepMin = info[10] << 8 | info[9];
                    shallowSleepMin = info[12] << 8 | info[11];
                    breakSleep = info[14] << 8 | info[13];
                    breakCount = info[16] << 8 | info[15];
                    startSleepH = info[17];
                    startSleepM = info[18];
                    NSLog(@"----------------------------------------每日一记");
                    sd = [NSEntityDescription insertNewObjectForEntityForName:@"SleepData" inManagedObjectContext:_context];
                    sd.date = [NSString stringWithFormat:@"%d%s%d%s%d%s",year,"年",month,"月",day,"日"];
                    sd.sleepTime = [NSNumber numberWithInt:sleepMin];
                    sd.sleepSecond = [NSNumber numberWithInt:sleepSecondMin];
                    sd.deepSleep = [NSNumber numberWithInt:deepSleepMin];
                    sd.shallowSleep = [NSNumber numberWithInt:shallowSleepMin];
                    sd.breakTime = [NSNumber numberWithInt:breakSleep];
                    sd.breakCount = [NSNumber numberWithInt:breakCount];
                    sd.startSleepH = [NSNumber numberWithInt:startSleepH];
                    sd.startSleepM = [NSNumber numberWithInt:startSleepM];
                    [_context save:nil];//每更新一次将数据存入数据表中
                    break;
                    //当日运动总记录 每日一笔 10进制存储
                case 54:
                    today_step = info[2] * 100 + info[1];
                    today_miles = (info[4] * 100 + info[3]) *10;
                    today_calorie = info[6] * 100  + info[5];
                    today_staticCalorie = info[8] * 100 + info[7];
                    today_year = info[10] * 100 + info[9];
                    today_mon = info[11];
                    today_day = info[12];
                    today_move = info[14]*100+info[13];
                    today_rateMax = info[15];
                    today_rateMin = info[16];
                    
                    md = [NSEntityDescription insertNewObjectForEntityForName:@"MoveData" inManagedObjectContext:_context];
                    md.steps = [NSNumber numberWithInt:today_step];
                    md.miles = [NSNumber numberWithInt:today_miles];
                    md.calorie = [NSNumber numberWithInt:today_miles];
                    md.staticCalorie = [NSNumber numberWithInt:today_staticCalorie];
                    md.date = [NSString stringWithFormat:@"%d%s%d%s%d%s",today_year,"年",today_mon,"月",today_day,"日"];
                    md.moveTime = [NSNumber numberWithInt:today_move];
                    md.rateMax = [NSNumber numberWithInt:today_rateMax];
                    md.rateMin = [NSNumber numberWithInt:today_rateMin];
                    [_context save:nil];
                    
                    break;
                default:
                    NSLog(@"获取信息失败！");
                    break;
            }
        }
    }
    
}

//打开or创建数据库
- (void) openDB{
    NSManagedObjectModel *model = [NSManagedObjectModel mergedModelFromBundles:nil];
    NSPersistentStoreCoordinator *store = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:model];
    
    NSArray *doc = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [doc[0] stringByAppendingPathComponent:@"shouhuan.db"];
    NSURL *url = [NSURL fileURLWithPath:path];
    NSError *error = nil;
    [store addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:url options:nil error:&error];
    if (error) {
        NSLog(@"打开数据库失败！");
    } else {
        NSLog(@"打开数据库成功！");
    }
    
    _context = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    
    _context.persistentStoreCoordinator = store;
}

@end
