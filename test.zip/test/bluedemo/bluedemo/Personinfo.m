//
//  Personinfo.m
//  bluedemo
//
//  Created by user on 16/8/2.
//  Copyright © 2016年 user. All rights reserved.
//

#import "Personinfo.h"

@implementation Personinfo


@end
