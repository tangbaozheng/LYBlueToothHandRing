//
//  ViewController.m
//  bluedemo
//
//  Created by user on 16/7/29.
//  Copyright © 2016年 user. All rights reserved.
//

#import "ViewController.h"
#import "btconnect.h"
#import "SleepData.h"
#import "SleepData+CoreDataProperties.h"
#import "MoveData.h"
#import "MoveData+CoreDataProperties.h"



@interface ViewController ()


@property (strong ,nonatomic) Personinfo *pi;//个人身体信息
@property (strong,nonatomic) btconnect *bt;//蓝牙连接模块



@end

//int转byte类型
Byte getByte(int value){
    return 0xff & value;
}





@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.bt = [[btconnect alloc] init];//初始化蓝牙连接模块对象
    [self.bt centralManager];//创建蓝牙连接
    [self.bt openDB];//创建数据库
}

//蓝牙通信 写ble
- (void) writeData:(Byte[])shuzu andlength:(int)length{

    NSData *data = [NSData dataWithBytes:shuzu length:length];//数组的长度
    [self.bt.peripheral writeValue:data forCharacteristic:self.bt.charac_W type:CBCharacteristicWriteWithResponse];
}

//初始化个人信息
- (Personinfo *) pi{
    if (!_pi) {
        self.pi=[[Personinfo alloc] init];
    }
    return  self.pi;
}


//设置手环等信息 结合ui实现
- (void)setPersonInfo:(id)sender{
    //字符串转Int后转byte；
    self.pi.height = getByte([@"123" intValue]);
    Byte zd[] = {self.pi.height,2,3};
    //NSData *data = [NSData dataWithBytes:zd length:1];
    [self writeData:zd andlength:4];

}

//设置屏保
- (void)setScreen{
    Byte time[]={30};
//    NSData *data = [NSData dataWithBytes:time length:1];
    [self writeData:time andlength:1];
}

//设置闹钟
- (void)setAlarm{
    Byte setTime[]={12,30,14,15};
    [self writeData:setTime andlength:15];
}


//获取当前时间
- (void)setCurrentTime{
   
    NSDate *now = [NSDate date];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSUInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    NSDateComponents *dateComponent = [calendar components:unitFlags fromDate:now];
    
    long int year = [dateComponent year];
    long int month = [dateComponent month];
    long int day = [dateComponent day];
    long int hour = [dateComponent hour];
    long int minute = [dateComponent minute];
    long int second = [dateComponent second];
    Byte currentTime[]={year,month,day,hour,minute,second};
    [self writeData:currentTime andlength:11];
}

//来电提醒(未实现)
- (void) phoneAlert{
    
}




//查询每日所有睡眠数据
- (void)sleepDataLog{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"SleepData"];
    request.predicate = [NSPredicate predicateWithFormat:@"order by date DESC"];
    NSArray *array = [self.bt.context executeFetchRequest:request error:nil];
    for (SleepData *sd in array) {
        NSLog(@"%@ %@ %@ %@ %@ %@ %@ %@ %@ %@ %@", sd.date, sd.sleepTime, sd.sleepSecond, sd.deepSleep, sd.shallowSleep, sd.breakTime, sd.breakCount, sd.startSleepH, @"时", sd.startSleepM, @"分" );
    }
    
}

//查询每日所有运动数据
- (void)moveDataLog{
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"MoveData"];
    request.predicate = [NSPredicate predicateWithFormat:@"order by date DESC"];
    NSArray *array = [self.bt.context executeFetchRequest:request error:nil];
    for (MoveData *md in array) {
        NSLog(@"%@ %@ %@ %@ %@ %@ %@ %@", md.date, md.steps, md.miles, md.calorie, md.staticCalorie, md.moveTime, md.rateMax, md.rateMin);
    }
}

//清除睡眠数据记录
- (void) removeSleepData{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"SleepData"];
    NSArray *array = [self.bt.context executeFetchRequest:request error:nil];
    for (SleepData *sd in array) {
        [self.bt.context deleteObject:sd];
    }
    if ([self.bt.context save:nil]) {
        NSLog(@"清除成功");
    }else{
        NSLog(@"清除失败");
    }
}


//清除运动数据记录
- (void) removeMoveData{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"MoveData"];
    request.predicate = [NSPredicate predicateWithFormat:@"order by date DESC"];
    NSArray *array = [self.bt.context executeFetchRequest:request error:nil];
    for (MoveData *md in array) {
        [self.bt.context deleteObject:md];
    }
    if ([self.bt.context save:nil]) {
        NSLog(@"清除成功");
    }else{
        NSLog(@"清除失败");
    }
}




@end
