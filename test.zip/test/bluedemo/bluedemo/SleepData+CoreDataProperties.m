//
//  SleepData+CoreDataProperties.m
//  bluedemo
//
//  Created by user on 16/8/6.
//  Copyright © 2016年 user. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "SleepData+CoreDataProperties.h"

@implementation SleepData (CoreDataProperties)

@dynamic date;
@dynamic sleepTime;
@dynamic sleepSecond;
@dynamic deepSleep;
@dynamic shallowSleep;
@dynamic breakTime;
@dynamic breakCount;
@dynamic startSleepH;
@dynamic startSleepM;

@end
