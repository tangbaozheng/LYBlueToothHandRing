//
//  btorder.h
//  bluedemo
//
//  Created by user on 16/8/8.
//  Copyright © 2016年 user. All rights reserved.
//



//蓝牙支付模块（未实现）；
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

#define kServiceUUID @" 14701820‐620a‐3973‐7c78‐9cfff0876abd"  //service uuid
#define kCharacteristicUUID1 @" 14702856‐620a‐3973‐7c78‐9cfff0876abd"// characteristic uuid write
#define kCharacteristicUUID2 @" 14702853‐620a‐3973‐7c78‐9cfff0876abd"// characteristic uuid notify


@interface btorder : NSObject<CBCentralManagerDelegate,CBPeripheralDelegate>

@property (strong, nonatomic) CBCentralManager *centralManager;
@property (strong, nonatomic) CBPeripheral *peripheral;
@property (strong, nonatomic) NSMutableArray *peripherals;
@property (strong, nonatomic) CBCharacteristic *charac_W;
@property (strong, nonatomic) CBCharacteristic *charac_R;


@end
