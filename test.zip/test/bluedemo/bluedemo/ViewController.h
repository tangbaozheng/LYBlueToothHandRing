//
//  ViewController.h
//  bluedemo
//
//  Created by user on 16/7/29.
//  Copyright © 2016年 user. All rights reserved.
//


//蓝牙通信模块
#import <UIKit/UIKit.h>
#import "Personinfo.h"


@interface ViewController : UIViewController



@end

