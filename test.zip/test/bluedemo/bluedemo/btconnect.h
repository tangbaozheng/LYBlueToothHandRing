//
//  btconnect.h
//  bluedemo
//
//  Created by user on 16/8/3.
//  Copyright © 2016年 user. All rights reserved.
//


//蓝牙连接模块
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreData/CoreData.h>
#import "Personinfo.h"


#define kServiceUUID @" 14701820‐620a‐3973‐7c78‐9cfff0876abd"  //service uuid
#define kCharacteristicUUID1 @" 14702856‐620a‐3973‐7c78‐9cfff0876abd"// characteristic uuid write
#define kCharacteristicUUID2 @" 14702853‐620a‐3973‐7c78‐9cfff0876abd"// characteristic uuid notify

@interface btconnect : NSObject<CBCentralManagerDelegate,CBPeripheralDelegate>



//创建数据库
- (void) openDB;


@property (strong, nonatomic) CBCentralManager *centralManager;
@property (strong, nonatomic) CBPeripheral *peripheral;
@property (strong, nonatomic) NSMutableArray *peripherals;
@property (strong, nonatomic) CBCharacteristic *charac_W;
@property (strong, nonatomic) CBCharacteristic *charac_N;
@property (strong, nonatomic) NSManagedObjectContext *context;


@end
