//
//  Personinfo.h
//  bluedemo
//
//  Created by user on 16/8/2.
//  Copyright © 2016年 user. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Personinfo : NSObject


//身高 年龄 体重 屏保 闹钟时 闹钟分 久坐开始时间  久坐结束时间
@property Byte height;
@property Byte age;
@property Byte eight;
@property Byte screenInternal;
@property Byte alarmHour;
@property Byte alarmMin;





@end
