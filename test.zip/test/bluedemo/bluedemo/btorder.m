//
//  btorder.m
//  bluedemo
//
//  Created by user on 16/8/8.
//  Copyright © 2016年 user. All rights reserved.
//

#import "btorder.h"

@implementation btorder


//创建中心设备
- (CBCentralManager *) centralManager{
    if (!self.centralManager) {
        self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return self.centralManager;
}


//保存外设
- (NSMutableArray *) peripherals{
    if (!_peripherals) {
        self.peripherals = [NSMutableArray array];
    }
    return self.peripherals;
}

//监测蓝牙状态改变
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    if (central.state == CBCentralManagerStatePoweredOn) {
        //扫描外围设备
        [self.centralManager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:kServiceUUID]] options:nil];
    }else{
        NSLog(@"未打开蓝牙设备或此设备不支持蓝牙4.0");
    }
    
}

//找到外围设备
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI{
    NSLog(@"找到手环外设");
    [self.centralManager stopScan];//找到后停止扫描
    if (peripheral) {
        if (![self.peripherals containsObject:peripheral]) {
            [self.peripherals addObject:peripheral];
            
        }
        self.peripheral = peripheral;
    }
    
    
    //链接外围设备
    [self.centralManager connectPeripheral:peripheral options:nil];
}

//链接到所选外围设备
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    peripheral.delegate = self;//设置当前设备为代理设备
    
    //发现此设备的服务
    [self.peripheral discoverServices:@[[CBUUID UUIDWithString:kServiceUUID]]];
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"连接失败，请重新连接");
    //链接外围设备
    [self.centralManager connectPeripheral:peripheral options:nil];//重新连接手环
}

//找到服务后
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    if (error) {
        NSLog(@"出现错误:%@",error.localizedDescription);
        //发现此设备的服务
        [self.peripheral discoverServices:@[[CBUUID UUIDWithString:kServiceUUID]]];//重新查找手环服务
    }
    //    CBUUID *serverUUID = [CBUUID UUIDWithString:kServiceUUID];
    
    //手环特征数组
    NSArray<CBUUID *> *charateristUUID = @[[CBUUID UUIDWithString:kCharacteristicUUID1],[CBUUID UUIDWithString:kCharacteristicUUID2]];
    
    for (CBService *service in peripheral.services) {
        if ([service.UUID.UUIDString isEqualToString:kServiceUUID]) {
            //发现手环特征
            [self.peripheral discoverCharacteristics:charateristUUID forService:service];
        }
        
    }
}

//找到该服务下的2个特征
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    if (error) {
        //手环特征数组
        NSArray<CBUUID *> *charateristUUID = @[[CBUUID UUIDWithString:kCharacteristicUUID1],[CBUUID UUIDWithString:kCharacteristicUUID2]];
        //发现手环特征
        [self.peripheral discoverCharacteristics:charateristUUID forService:service];
    } else {
        for (CBCharacteristic *character in service.characteristics) {
            if ([character.UUID.UUIDString isEqualToString:kCharacteristicUUID1]) {
                
                //把数据放在字节数组中写到外围设备
                if (peripheral && character) {
                    self.charac_W = character;
                }
                
            } else if([character.UUID.UUIDString isEqualToString:kCharacteristicUUID2]){
                
                //订阅手环通知
                if (peripheral && character) {
                    self.charac_R = character;
                    [self.peripheral setNotifyValue:YES forCharacteristic:character];
                    [self.peripheral readValueForCharacteristic:character];
                }
                
            }
            //      [self.peripheral discoverDescriptorsForCharacteristic:character];
            //        [self.peripheral readValueForCharacteristic:character];
        }
    }
}











@end


