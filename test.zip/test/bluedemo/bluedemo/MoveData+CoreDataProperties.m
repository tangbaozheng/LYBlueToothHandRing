//
//  MoveData+CoreDataProperties.m
//  bluedemo
//
//  Created by user on 16/8/6.
//  Copyright © 2016年 user. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "MoveData+CoreDataProperties.h"

@implementation MoveData (CoreDataProperties)

@dynamic steps;
@dynamic miles;
@dynamic calorie;
@dynamic staticCalorie;
@dynamic date;
@dynamic moveTime;
@dynamic rateMax;
@dynamic rateMin;

@end
